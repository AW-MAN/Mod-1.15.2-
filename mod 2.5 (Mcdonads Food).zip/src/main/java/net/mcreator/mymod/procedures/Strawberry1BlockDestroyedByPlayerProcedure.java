package net.mcreator.mymod.procedures;

import net.minecraftforge.items.ItemHandlerHelper;

import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.Entity;

import net.mcreator.mymod.item.StrawberryItem;
import net.mcreator.mymod.MyMod10625ModElements;

import java.util.Map;

@MyMod10625ModElements.ModElement.Tag
public class Strawberry1BlockDestroyedByPlayerProcedure extends MyMod10625ModElements.ModElement {
	public Strawberry1BlockDestroyedByPlayerProcedure(MyMod10625ModElements instance) {
		super(instance, 17);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure Strawberry1BlockDestroyedByPlayer!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (entity instanceof PlayerEntity) {
			ItemStack _setstack = new ItemStack(StrawberryItem.block, (int) (1));
			_setstack.setCount((int) 10);
			ItemHandlerHelper.giveItemToPlayer(((PlayerEntity) entity), _setstack);
		}
	}
}
