package net.mcreator.mymod.procedures;

import net.minecraft.world.GameType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.Entity;

import net.mcreator.mymod.MyMod10625ModElements;

import java.util.Map;

@MyMod10625ModElements.ModElement.Tag
public class Buttonpressed4Procedure extends MyMod10625ModElements.ModElement {
	public Buttonpressed4Procedure(MyMod10625ModElements instance) {
		super(instance, 36);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure Buttonpressed4!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (entity instanceof PlayerEntity)
			((PlayerEntity) entity).setGameType(GameType.SURVIVAL);
	}
}
