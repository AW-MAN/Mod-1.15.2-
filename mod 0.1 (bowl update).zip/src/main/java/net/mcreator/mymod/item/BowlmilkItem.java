
package net.mcreator.mymod.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.UseAction;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.Food;

import net.mcreator.mymod.MyMod10625ModElements;

@MyMod10625ModElements.ModElement.Tag
public class BowlmilkItem extends MyMod10625ModElements.ModElement {
	@ObjectHolder("my_mod10625:bowlmilk")
	public static final Item block = null;
	public BowlmilkItem(MyMod10625ModElements instance) {
		super(instance, 49);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new FoodItemCustom());
	}
	public static class FoodItemCustom extends Item {
		public FoodItemCustom() {
			super(new Item.Properties().group(ItemGroup.FOOD).maxStackSize(12).food((new Food.Builder()).hunger(4).saturation(0.3f).build()));
			setRegistryName("bowlmilk");
		}

		@Override
		public UseAction getUseAction(ItemStack par1ItemStack) {
			return UseAction.DRINK;
		}

		@Override
		public net.minecraft.util.SoundEvent getEatSound() {
			return net.minecraft.util.SoundEvents.ENTITY_GENERIC_DRINK;
		}
	}
}
