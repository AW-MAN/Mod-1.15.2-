package net.mcreator.mymod.procedures;

import net.minecraftforge.items.ItemHandlerHelper;

import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.Entity;

import net.mcreator.mymod.item.MoneyItem;
import net.mcreator.mymod.item.FriesItem;
import net.mcreator.mymod.item.BurgerItem;
import net.mcreator.mymod.MyMod10625ModElements;

import java.util.Map;

@MyMod10625ModElements.ModElement.Tag
public class Buttonpressed6Procedure extends MyMod10625ModElements.ModElement {
	public Buttonpressed6Procedure(MyMod10625ModElements instance) {
		super(instance, 40);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				System.err.println("Failed to load dependency entity for procedure Buttonpressed6!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if ((Double.NaN >= 8)) {
			if (entity instanceof PlayerEntity) {
				ItemStack _stktoremove = new ItemStack(MoneyItem.block, (int) (1));
				((PlayerEntity) entity).inventory.clearMatchingItems(p -> _stktoremove.getItem() == p.getItem(), (int) 8);
			}
			if (entity instanceof PlayerEntity) {
				ItemStack _setstack = new ItemStack(BurgerItem.block, (int) (1));
				_setstack.setCount((int) 1);
				ItemHandlerHelper.giveItemToPlayer(((PlayerEntity) entity), _setstack);
			}
			if (entity instanceof PlayerEntity) {
				ItemStack _setstack = new ItemStack(FriesItem.block, (int) (1));
				_setstack.setCount((int) 1);
				ItemHandlerHelper.giveItemToPlayer(((PlayerEntity) entity), _setstack);
			}
		}
		if ((Double.NaN <= 8)) {
			System.out.println("You Have not enough money!");
		}
	}
}
