package net.mcreator.mymod.procedures;

import net.minecraft.item.ItemStack;

import net.mcreator.mymod.MyMod10625ModElements;

import java.util.Map;

@MyMod10625ModElements.ModElement.Tag
public class UraniumnotsafeItemInHandTickProcedure extends MyMod10625ModElements.ModElement {
	public UraniumnotsafeItemInHandTickProcedure(MyMod10625ModElements instance) {
		super(instance, 24);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("itemstack") == null) {
			if (!dependencies.containsKey("itemstack"))
				System.err.println("Failed to load dependency itemstack for procedure UraniumnotsafeItemInHandTick!");
			return;
		}
		ItemStack itemstack = (ItemStack) dependencies.get("itemstack");
		((itemstack)).setDamage((int) 1);
	}
}
